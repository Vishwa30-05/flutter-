package com.deba.miniprofile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
